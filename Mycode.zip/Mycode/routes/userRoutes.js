const express = require('express');
const {
    getAllUsers,
    registerController,
    loginController
} = require('../controllers/userController');

const router = express.Router();

// Get all users method GET
router.get('/all-users', getAllUsers);
// Get register method
router.post('/register', registerController);
// Get login method
router.post('/login', loginController);



module.exports = router;
